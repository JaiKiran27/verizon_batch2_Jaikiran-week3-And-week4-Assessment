class CustomerApp {  
    public static void main(String[] args) {  
        System.out.println("Hello Guys This is A Test To Use Few Docker Commands and Print 'This is CustomerApp app' \n by using Docker");  
    }  
}  
